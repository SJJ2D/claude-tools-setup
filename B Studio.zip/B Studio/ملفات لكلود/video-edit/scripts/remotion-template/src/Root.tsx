import React from 'react';
import {Composition} from 'remotion';
import {Ad} from './Ad';
import {DUR_F, FPS, VW, VH} from './theme';

export const RemotionRoot: React.FC = () => (
  <Composition id="Ad" component={Ad} durationInFrames={DUR_F}
    fps={FPS} width={VW} height={VH} />
);
